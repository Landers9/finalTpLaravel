<script src="<?php echo e(asset('assets/js/jquery-3.3.1.min.js')); ?>"></script>
<!-- jquery migrate js link -->
<script src="<?php echo e(asset('assets/js/jquery-migrate-3.0.0.js')); ?>"></script>
<!-- bootstrap js link -->
<script src="<?php echo e(asset('assets/js/bootstrap.min.js')); ?>"></script>
<!-- lightcase js link -->
<script src="<?php echo e(asset('assets/js/lightcase.js')); ?>"></script>
<!-- wow js link -->
<script src="<?php echo e(asset('assets/js/wow.min.js')); ?>"></script>
<!-- nice select js link -->
<script src="<?php echo e(asset('assets/js/jquery.nice-select.min.js')); ?>"></script>
<!-- datepicker js link -->
<script src="<?php echo e(asset('assets/js/datepicker.min.js')); ?>"></script>

<script src="<?php echo e(asset('assets/js/datepicker.en.js')); ?>"></script>
<!-- wickedpicker js link -->
<script src="<?php echo e(asset('assets/js/wickedpicker.min.js')); ?>"></script>
<!-- owl carousel js link -->
<script src="<?php echo e(asset('assets/js/owl.carousel.min.js')); ?>"></scrip>
<!-- jquery ui js link -->
<script src="<?php echo e(asset('assets/js/jquery-ui.min.js')); ?>"></script>
<!-- main js link -->
<script src="<?php echo e(asset('assets/js/main.js')); ?>"></script><?php /**PATH C:\Users\TOSHIBA\Documents\laravelProjets\Nouveau dossier\tpLaravel\resources\views/jslink.blade.php ENDPATH**/ ?>