<link rel="shortcut icon" type="image/png" href="<?php echo e(asset('assets/images/favicon.jpg')); ?>"/>

<link rel="stylesheet" href="<?php echo e(asset('assets/css/fontawesome.min.css')); ?>"> 
<!-- bootstrap css link -->
<link rel="stylesheet" href="<?php echo e(asset('assets/css/bootstrap.min.css')); ?>">
<!-- lightcase css link -->
<link rel="stylesheet" href="<?php echo e(asset('assets/css/lightcase.css')); ?>">
<!-- animate css link -->
<link rel="stylesheet" href="<?php echo e(asset('assets/css/animate.css')); ?>">
<!-- nice select css link -->
<link rel="stylesheet" href="<?php echo e(asset('assets/css/nice-select.css')); ?>">
<!-- datepicker css link -->
<link rel="stylesheet" href="<?php echo e(asset('assets/css/datepicker.min.css')); ?>">
<!-- wickedpicker css link -->
<link rel="stylesheet" href="<?php echo e(asset('assets/css/wickedpicker.min.css')); ?>">
<!-- jquery ui css link -->
<link rel="stylesheet" href="<?php echo e(asset('assets/css/jquery-ui.min.css')); ?>">
<!-- owl carousel css link -->
<link rel="stylesheet" href="<?php echo e(asset('assets/css/owl.carousel.min.css')); ?>">
<!-- main style css link -->
<link rel="stylesheet" href="<?php echo e(asset('assets/css/main.css')); ?>"><?php /**PATH C:\Users\TOSHIBA\Documents\laravelProjets\Nouveau dossier\tpLaravel\resources\views/csslink.blade.php ENDPATH**/ ?>