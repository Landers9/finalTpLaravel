<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <title>Rental-Car</title>
  <link rel="shortcut icon" type="image/png" href="<?php echo e(asset('assets/images/favicon.jpg')); ?>"/>
  <!-- site favicon -->
  <?php echo $__env->make("csslink", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</head>
<body>

  <!-- preloader start -->
  <?php echo $__env->make('header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

  <!-- inner-apge-banner start -->
  <section class="inner-page-banner bg_img overlay-3" data-background="assets/images/inner-page-bg.jpg">
    <div class="container">
      <div class="row">
        <div class="col-md-12">
          <h2 class="page-title">Rent</h2>
          <ol class="page-list">
            <li><a href="index.html"><i class="fa fa-home"></i> Home</a></li>
            <li><a href="#0">Car</a></li>
            <li>Rent</li>
          </ol>
        </div>
      </div>
    </div>
  </section>
  <!-- inner-apge-banner end -->

  <div class="container pt-120">
    <div style="width:50%;">
      <?php if(session()->has('message')): ?>
          <div class="alert alert-success">
            <?php echo e(session()->get('message')); ?>

          </div>
      <?php endif; ?>
    </div>
  </div>

  <!-- reservation-section start -->
  <section class="reservation-section pt-120 pb-120">
    <div class="container">
      <div class="row">
        <div class="col-lg-8">
          <div class="reservation-details-area">
            <div class="thumb">
              <img src="<?php echo e(asset('storage/'.$car->image)); ?>" alt="images">
            </div>
            <div class="content">
              <div class="content-block">
                <h3 class="car-name"> <?php echo e($car->name); ?></h3>
                <span class="price"> <?php echo e($car->prix); ?> per day</span>
                <p><?php echo e($car->description); ?>

                </p>
              </div>
              <form class="reservation-form" method="post" action="/emprunt">
                <?php echo e(csrf_field()); ?>


                <div class="content-block">
                  <h3 class="title">extra benifit and fee</h3>
                  <div class="row">
                    <div class="form-group col-md-6">
                      <i class="fa fa-calendar"></i>
                      <input type='text' class='form-control has-icon datepicker-here' data-language='en' placeholder="Pickup Date/Time" name="date_debut_emprunt">
                    </div>
                    <div class="form-group col-md-6">
                      <i class="fa fa-calendar"></i>
                      <input type='text' class='form-control has-icon datepicker-here' data-language='en' placeholder="Drop Off Date/Time" name="date_fin_emprunt">
                    </div>
                    <div class="form-group col-md-6">
                      <input type="hidden" name="id_car" value="<?php echo e($car->id); ?>">
                    </div>
                  </div>
                </div>
                <div class="content-block">
                  <h3 class="title">payment method</h3>
                  <div class="row">
                    <div class="col-lg-6 form-group">
                      <select name='payement'>
                        <option>Select Payment Methos</option>
                        <option value='Paypal'>Paypal</option>
                        <option value='Payoneer'>Payoneer</option>
                        <option value='Visa Card'>Visa Card</option>
                      </select>
                    </div>
                  </div>
                </div>
                <div class="content-block">
                  <h3 class="title">addisonal information</h3>
                  <div class="row">
                    <div class="col-lg-12 form-group">
                      <textarea placeholder="Write addisonal information in here" name='info'></textarea>
                    </div>
                    <div class="col-lg-12">
                      <button type="reset" class="cmn-btn bg-black">Cancel</button>
                      <button type="submit" class="cmn-btn">reservation</button>
                    </div>
                  </div>
                </div>
              </form>
            </div>
          </div>
        </div>
        <div class="col-lg-4">
          <aside class="sidebar">
            <div class="widget widget-all-cars">
              <h4 class="widget-title">Car Features</h4>
              <ul class="cars-list">
                <li><a href="#0">Name : <?php echo e($car->name); ?></a></li>
                <li><a href="#0">Model : <?php echo e($car->modele['name']); ?></a></li>
                <li><a href="#0">Marque : <?php echo e($car->marque['name']); ?></a></li>
                <li><a href="#0">Vitesse : <?php echo e($car->vitesse); ?></a></li>
                <li><a href="#0">Price : <?php echo e($car->prix); ?></a></li>
              </ul>
            </div>
          </aside>
        </div>
      </div>
    </div>
  </section>
  <!-- reservation-section end -->

  <!-- footer-section start -->
  <?php echo $__env->make('footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <!-- footer-section end -->
  
  <!-- scroll-to-top start -->
  <div class="scroll-to-top">
    <span class="scroll-icon">
      <i class="fa fa-rocket"></i>
    </span>
  </div>
  <!-- scroll-to-top end -->
  <?php echo $__env->make("jslink", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  
</body>

</html><?php /**PATH C:\Users\TOSHIBA\Documents\laravelProjets\tpLara\resources\views/reservation.blade.php ENDPATH**/ ?>